package relop;

/**
 * The simplest of all join algorithms: nested loops (see textbook, 3rd edition,
 * section 14.4.1, page 454).
 */
public class SimpleJoin extends Iterator {
	private Iterator leftIterator;
	private Iterator rightIterator;
	private Predicate[] preds;
	private Tuple currentTuple;
	private Tuple leftTuple;
	private boolean tf;
	private int i;
	private int size;

  /**
   * Constructs a join, given the left and right iterators and join predicates
   * (relative to the combined schema).
   */
  public SimpleJoin(Iterator left, Iterator right, Predicate... preds) {
    //throw new UnsupportedOperationException("Not implemented");
	leftIterator = left;
	rightIterator = right;
	this.preds = preds;
	size = this.preds.length;
	
	Schema newSchema = Schema.join(leftIterator.getSchema(), rightIterator.getSchema());
	this.setSchema(newSchema);

	currentTuple = null;
	tf = false;
	if(leftIterator.hasNext()){
		leftTuple = leftIterator.getNext();
		while(!tf){
			while(rightIterator.hasNext() && !tf){
				currentTuple = Tuple.join(leftTuple, rightIterator.getNext(), newSchema);
				tf = true;
				while( tf && (i < size)){
					tf& = this.preds[i].evaluate(currentTuple);					
					i++;				
				}			
			}
			if(leftIterator.hasNext() && !tf){
				rightIterator.restart();
				leftTuple = leftIterator.getNext();			
			}		
		}	
	}
 }

  /**
   * Gives a one-line explaination of the iterator, repeats the call on any
   * child iterators, and increases the indent depth along the way.
   */
  public void explain(int depth) {
    throw new UnsupportedOperationException("Not implemented");
  }

  /**
   * Restarts the iterator, i.e. as if it were just constructed.
   */
  public void restart() {
    //throw new UnsupportedOperationException("Not implemented");
		leftIterator.restart();
		rightIterator.restart();
		
		currentTuple = null; tf = null;
		if(leftIterator.hasNext()){
			leftTuple = leftIterator.getNext();		
			
			leftTuple = leftIterator.getNext();
			
			while (!tf){
				while(rightIterator.hasNext() && !tf){
					currentTuple = Tuple.join(leftTuple, rightIterator.getNext(), this.getSchema());
					tf = true;
					while( tf && (i < size)){
						tf& = this.preds[i].evaluate(currentTuple);		
						i++;			
					}				
				}
				if(!tf){
					rightIterator.restart();
					leftTuple = leftIterator.getNext();				
				}				
			}		
		}
	
  }

  /**
   * Returns true if the iterator is open; false otherwise.
   */
  public boolean isOpen() {
    //throw new UnsupportedOperationException("Not implemented");
	return leftIterator.isOpen() && rightIterator.isOpen();
  }

  /**
   * Closes the iterator, releasing any resources (i.e. pinned pages).
   */
  public void close() {
    //throw new UnsupportedOperationException("Not implemented");
	leftIterator.close();
	rightIterator.close();
  }

  /**
   * Returns true if there are more tuples, false otherwise.
   */
  public boolean hasNext() {
    //throw new UnsupportedOperationException("Not implemented");
	return currentTuple != null;
  }

  /**
   * Gets the next tuple in the iteration.
   * 
   * @throws IllegalStateException if no more tuples
   */
  public Tuple getNext() {
    //throw new UnsupportedOperationException("Not implemented");

	if(currentTuple == null){
		throw new IllegalStateException("Out of tuples");	
	}
	
	Tuple goingOut = currentTuple;
	currentTuple = null;
	tf = false;
	while( (rightIterator.hasNext() || leftIterator.hasNext()) && !tf){
		while( rightIterator.hasNext() && !tf){
			currentTuple = Tuple.join(leftTuple, rightIterator.getNext(), this.getSchema());
			tf = true;
			while( tf && ( i < size)){
				tf& = this.preds[i].evaluate(currentTuple);				
				i++;			
			}		
		}
		if(!tf){
			rightIterator.restart();
			leftTuple = leftIterator.getNext();		
		}	
	}
	return goingOut;
  }

} // public class SimpleJoin extends Iterator
