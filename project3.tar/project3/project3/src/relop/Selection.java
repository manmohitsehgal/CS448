package relop;

/**
 * The selection operator specifies which tuples to retain under a condition; in
 * Minibase, this condition is simply a set of independent predicates logically
 * connected by OR operators.
 */
public class Selection extends Iterator {

  /**
   * Constructs a selection, given the underlying iterator and predicates.
   */


	private Iterator iter;
	private Tuple	 currentTupple;
	private boolean	 tf;
	private int i; // i
	private int size; // sz
	private Predicate[] preds;

	
  public Selection(Iterator iter, Predicate... preds) {
    //throw new UnsupportedOperationException("Not implemented");
	this.iter = iter;
	this.preds = preds;
		
	this.setSchema(this.iter.getSchema());
	size = this.preds.length;
	currentTuple = null;
	tf = false;
	int j;
	for(j = 0; j<iter.hasNext() && !tf; i++){ // need to rewrite this loop in a different way.
		currentTuple = iter.getNext();
		tf = true;
		for(i = 0; tf && (i < size); i++){
			tf& = this.preds[i].evaluate(currentTuple); // need to somehow re write this line		
		}	
	}
  }

  /**
   * Gives a one-line explaination of the iterator, repeats the call on any
   * child iterators, and increases the indent depth along the way.
   */
  public void explain(int depth) {
    //throw new UnsupportedOperationException("Not implemented");
	String myString = "";
	myString = myString + this.preds[0].toString();
	while(i<size){
		myString += " & " + this.preds[i].toString();
		i++;	
	}
	System.out.println("Data :" + myString);
	indent(depth+1);
  }

  /**
   * Restarts the iterator, i.e. as if it were just constructed.
   */
  public void restart() {
    throw new UnsupportedOperationException("Not implemented");
	iter.restart();
	currentTuple = null;
	tf = false;
	int j = 0;
	while (iter.hasNext() && !tf){
		currentTuple = iter.getNext();
		tf = true;
		for(i = 0; tf && (i < size); i++){
			tf& = this.preds[i].evaluate(currentTuple);		
		}	
	}
  }

  /**
   * Returns true if the iterator is open; false otherwise.
   */
  public boolean isOpen() {
    //throw new UnsupportedOperationException("Not implemented");
	return iter.isOpen();
  }

  /**
   * Closes the iterator, releasing any resources (i.e. pinned pages).
   */
  public void close() {
    //throw new UnsupportedOperationException("Not implemented");
	return iter.close();
  }

  /**
   * Returns true if there are more tuples, false otherwise.
   */
  public boolean hasNext() {
    //throw new UnsupportedOperationException("Not implemented");
		return currentTuple != null;
  }

  /**
   * Gets the next tuple in the iteration.
   * 
   * @throws IllegalStateException if no more tuples
   */
  public Tuple getNext() {
    //throw new UnsupportedOperationException("Not implemented");
	
	Tuple goingOut; 
	goingOut= currentTuple;
	currentTuple = null;
	
	tf = false;

	while(!tf){
		if(!(iter.hasNext()){
			currentTuple = null;
			break;		
		}
		else{
			currentTuple = iter.getNext();
			tf = true;
			for(i = 0; check && (i < size); i++){
				check& = this.preds[i].evaluate(currentTemple);			
			}		
		}	
	}
	return goingOut;


  }

} // public class Selection extends Iterator
