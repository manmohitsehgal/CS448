package relop;

/**
 * The projection operator extracts columns from a relation; unlike in
 * relational algebra, this operator does NOT eliminate duplicate tuples.
 */
public class Projection extends Iterator {

	private Iterator iter;
	private Integer [] integerFields;
	private Tuple currentTuple;
	private int i;
	private int size;
	private Tuple tempTuple;
	private Object[] objectValue;

  /**
   * Constructs a projection, given the underlying iterator and field numbers.
   */
  public Projection(Iterator iter, Integer... fields) {
    //throw new UnsupportedOperationException("Not implemented");
	this.iter = iter;
	this.fields = fields;
	size = this.fields.length;

	Schema newSchema = new Schema(size);
	while( i< size){
		newSchema.initField(i, this.iter.getSchema(), this.fields[i]);		
		i++;	
	}
	this.setSchema(newSchema);
	currentTuple = null;
	
	if(iter.hasNext()){
		tempTuple = iter.getNext();	
		objectValue = new Object[size];
		while(i < size){
			objectValue[i] = tempTuple.getField(this.fields[i]);
			i++;		
		}
		currentTuple = new Tuple(newSchema, objectValue);
	}
  }

  /**
   * Gives a one-line explaination of the iterator, repeats the call on any
   * child iterators, and increases the indent depth along the way.
   */
  public void explain(int depth) {
    //throw new UnsupportedOperationException("Not implemented");
  }

  /**
   * Restarts the iterator, i.e. as if it were just constructed.
   */
  public void restart() {
    //throw new UnsupportedOperationException("Not implemented");
	
	iter.restart();
	currentTuple = null;
	if(iter.hasNext()){
		tempTuple = iter.getNext();
		objectValue = new Object[size];
		while(i<size){
			objectValue[i] = temp.getField(this.fields[i]);
			i++;		
		}
		currentTuple = new Tuple(this.getSchema(), objectValue);	
	}
  }

  /**
   * Returns true if the iterator is open; false otherwise.
   */
  public boolean isOpen() {
    //throw new UnsupportedOperationException("Not implemented");
	return iter.isOpen();
  }

  /**
   * Closes the iterator, releasing any resources (i.e. pinned pages).
   */
  public void close() {
   // throw new UnsupportedOperationException("Not implemented");
		iter.close();
  }

  /**
   * Returns true if there are more tuples, false otherwise.
   */
  public boolean hasNext() {
    //throw new UnsupportedOperationException("Not implemented");
	return currentTuple != null;	  
}

  /**
   * Gets the next tuple in the iteration.
   * 
   * @throws IllegalStateException if no more tuples
   */
  public Tuple getNext() {
    //throw new UnsupportedOperationException("Not implemented");
	if (currentTuple == null){
		throw IllegalStateException("Out of Tuples");	
	}
	
	Tuple goingOut = currentTuple;
	currentTuple = null;
	if(iter.getNext()){
		tempTuple = iter.getNext();
		objectValue = new Object[size];
		while(i < size){
			objectValue[i] = tempTuple.getField(this.fields[i]);
			i++;		
		}	
		currentTuple = new Tuple(this.getSchema(), objectValue);
	}
	return goingOut;
  }

} // public class Projection extends Iterator
