CS 448
Manmohit Sehgal
Project 1

I have create views as they helped me to break down my query and understand it in a simpler way. I have tested my queries thoroughly and they work as expected.
Also I have used the following:
 
set serveroutput on
set heading on
set feedback off
set linesize 32000

The queries still run the way they should.


-- In query 7 I assumed that we have to return 0s and everything else as well. 
