package relop;

import global.SearchKey;
import heap.HeapFile;
import index.HashIndex;
import index.HashScan;

/**
 * Wrapper for hash scan, an index access method.
 */

/*
 * TODO :
 * restart()
 * isOpen ()
 * close()
 * hasNext()
 * getNext()
 */




public class KeyScan extends Iterator {

  /**
   * Constructs an index scan, given the hash index and schema.
   */

	private HashIndex	indexToHash;
	private SeachKey	keyToSearch;
	private HeapFile	theGivenHeapFile;
	private HashScan	hashToScan;	

  public KeyScan(Schema schema, HashIndex index, SearchKey key, HeapFile file) {
    //throw new UnsupportedOperationException("Not implemented");
	
	setSchema(schema);	
	indexToHash 	 = index;
	keyToSearch 	 = key;
	theGivenHeapFile = file;
	hashToScan		 = indexToHash.openScan(keyToSearch); 
	
  }

  /**
   * Gives a one-line explaination of the iterator, repeats the call on any
   * child iterators, and increases the indent depth along the way.
   */
  public void explain(int depth) {
    throw new UnsupportedOperationException("Not implemented");
  }

  /**
   * Restarts the iterator, i.e. as if it were just constructed.
   */
  public void restart() {
    //throw new UnsupportedOperationException("Not implemented");
		hashToScan.close(); // close the existing 
		hashToScan = hashIndex.openScan(keyToSearch);   
	}

  /**
   * Returns true if the iterator is open; false otherwise.
   */
  public boolean isOpen() {
    //throw new UnsupportedOperationException("Not implemented");
 	return hashToScan != null; 
 }

  /**
   * Closes the iterator, releasing any resources (i.e. pinned pages).
   */
  public void close() {
    //throw new UnsupportedOperationException("Not implemented");
	hashToScan =.close();
  }

  /**
   * Returns true if there are more tuples, false otherwise.
   */
  public boolean hasNext() {
    //throw new UnsupportedOperationException("Not implemented");
	return hashToScan.hasNext();
  }

  /**
   * Gets the next tuple in the iteration.
   * 
   * @throws IllegalStateException if no more tuples
   */
  public Tuple getNext() {
    //throw new UnsupportedOperationException("Not implemented");
	
	byte [] keyScanData;
	keyScanData = theGivenHeapFile.selectRecord(hashToScan.getNext());
	return new Tuple(getSchema(), data);

  }

} // public class KeyScan extends Iterator
